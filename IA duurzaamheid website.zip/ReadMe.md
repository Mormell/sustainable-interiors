# Uitleg over de opdracht Duurzame Interieurs

## Onderdelen
De opdracht bevat een hoofdpagina met een producten pagina.
Op de hoofdpagina is een deel van de opdracht terug te lezen.
De producten zijn terug te vinden op de producten pagina.

De webpagina is gemaakt doormiddel van HTML. In de ZIP-map zijn een aantal van deze paginas terug te vinden.
Om de opdracht het beste te begrijpen is het van belang te beginnen bij de Home.html. 
Dit doe je door er dubbel op te klikken.
De afbeeldingen worden ingeladen vanuit de images folder.

De webpagina bestaat heeft als extra toevoeging een contact pagina. Het doel hiervan is om een realitische pagina te creeren. Een gebruiker kan hierin feedback geven.
De vragen kan alleen de eigenaar van de website terug vinden in de 'vragen' tab.
De inlog gegevens hiervan zijn aanpasbaar in de code, maar zijn voor nu:
    Gebruikersnaam: Isabelle
    Wachtwoord: ILoveYou
        Let op! Het programma is hoofdletter gevoelig.

